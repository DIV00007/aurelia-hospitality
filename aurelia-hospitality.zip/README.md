# Aurelia Hospitality — Revenue Workspace (interactive demo)

Single-file, offline-capable revenue workspace demo. Open `index.html`, or use the live page.

- **Fictional brand and resorts; all data is synthetic** (as of 18 Oct 2026, covering 2026 and 2027).
- Not affiliated with any real hotel company.
- Try: Overview, Forecast, Pickup, Event Tracker, Rate & Inventory, Competition.
